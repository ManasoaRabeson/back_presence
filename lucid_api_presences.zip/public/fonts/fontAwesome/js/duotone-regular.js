(function () {
  'use strict';

  let _WINDOW = {};
  let _DOCUMENT = {};
  try {
    if (typeof window !== 'undefined') _WINDOW = window;
    if (typeof document !== 'undefined') _DOCUMENT = document;
  } catch (e) {}
  const {
    userAgent = ''
  } = _WINDOW.navigator || {};
  const WINDOW = _WINDOW;
  const DOCUMENT = _DOCUMENT;
  const IS_BROWSER = !!WINDOW.document;
  const IS_DOM = !!DOCUMENT.documentElement && !!DOCUMENT.head && typeof DOCUMENT.addEventListener === 'function' && typeof DOCUMENT.createElement === 'function';
  const IS_IE = ~userAgent.indexOf('MSIE') || ~userAgent.indexOf('Trident/');

  function _defineProperty(e, r, t) {
    return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
      value: t,
      enumerable: !0,
      configurable: !0,
      writable: !0
    }) : e[r] = t, e;
  }
  function ownKeys(e, r) {
    var t = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
      var o = Object.getOwnPropertySymbols(e);
      r && (o = o.filter(function (r) {
        return Object.getOwnPropertyDescriptor(e, r).enumerable;
      })), t.push.apply(t, o);
    }
    return t;
  }
  function _objectSpread2(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = null != arguments[r] ? arguments[r] : {};
      r % 2 ? ownKeys(Object(t), !0).forEach(function (r) {
        _defineProperty(e, r, t[r]);
      }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) {
        Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
      });
    }
    return e;
  }
  function _toPrimitive(t, r) {
    if ("object" != typeof t || !t) return t;
    var e = t[Symbol.toPrimitive];
    if (void 0 !== e) {
      var i = e.call(t, r || "default");
      if ("object" != typeof i) return i;
      throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return ("string" === r ? String : Number)(t);
  }
  function _toPropertyKey(t) {
    var i = _toPrimitive(t, "string");
    return "symbol" == typeof i ? i : i + "";
  }

  var S = {
      classic: {
        fa: "solid",
        fas: "solid",
        "fa-solid": "solid",
        far: "regular",
        "fa-regular": "regular",
        fal: "light",
        "fa-light": "light",
        fat: "thin",
        "fa-thin": "thin",
        fab: "brands",
        "fa-brands": "brands"
      },
      duotone: {
        fa: "solid",
        fad: "solid",
        "fa-solid": "solid",
        "fa-duotone": "solid",
        fadr: "regular",
        "fa-regular": "regular",
        fadl: "light",
        "fa-light": "light",
        fadt: "thin",
        "fa-thin": "thin"
      },
      sharp: {
        fa: "solid",
        fass: "solid",
        "fa-solid": "solid",
        fasr: "regular",
        "fa-regular": "regular",
        fasl: "light",
        "fa-light": "light",
        fast: "thin",
        "fa-thin": "thin"
      },
      "sharp-duotone": {
        fa: "solid",
        fasds: "solid",
        "fa-solid": "solid",
        fasdr: "regular",
        "fa-regular": "regular",
        fasdl: "light",
        "fa-light": "light",
        fasdt: "thin",
        "fa-thin": "thin"
      }
    };
  var s = "classic";
  var G = {
      classic: {
        900: "fas",
        400: "far",
        normal: "far",
        300: "fal",
        100: "fat"
      },
      duotone: {
        900: "fad",
        400: "fadr",
        300: "fadl",
        100: "fadt"
      },
      sharp: {
        900: "fass",
        400: "fasr",
        300: "fasl",
        100: "fast"
      },
      "sharp-duotone": {
        900: "fasds",
        400: "fasdr",
        300: "fasdl",
        100: "fasdt"
      }
    };
  var xt = {
      classic: {
        solid: "fas",
        regular: "far",
        light: "fal",
        thin: "fat",
        brands: "fab"
      },
      duotone: {
        solid: "fad",
        regular: "fadr",
        light: "fadl",
        thin: "fadt"
      },
      sharp: {
        solid: "fass",
        regular: "fasr",
        light: "fasl",
        thin: "fast"
      },
      "sharp-duotone": {
        solid: "fasds",
        regular: "fasdr",
        light: "fasdl",
        thin: "fasdt"
      }
    };
  var St = {
      kit: {
        fak: "kit",
        "fa-kit": "kit"
      },
      "kit-duotone": {
        fakd: "kit-duotone",
        "fa-kit-duotone": "kit-duotone"
      }
    };
  var Ct = {
    kit: {
      "fa-kit": "fak"
    },
    "kit-duotone": {
      "fa-kit-duotone": "fakd"
    }
  };
  var Wt = {
      kit: {
        fak: "fa-kit"
      },
      "kit-duotone": {
        fakd: "fa-kit-duotone"
      }
    };
  var Et = {
      kit: {
        kit: "fak"
      },
      "kit-duotone": {
        "kit-duotone": "fakd"
      }
    };

  var ua = {
      classic: {
        "fa-brands": "fab",
        "fa-duotone": "fad",
        "fa-light": "fal",
        "fa-regular": "far",
        "fa-solid": "fas",
        "fa-thin": "fat"
      },
      duotone: {
        "fa-regular": "fadr",
        "fa-light": "fadl",
        "fa-thin": "fadt"
      },
      sharp: {
        "fa-solid": "fass",
        "fa-regular": "fasr",
        "fa-light": "fasl",
        "fa-thin": "fast"
      },
      "sharp-duotone": {
        "fa-solid": "fasds",
        "fa-regular": "fasdr",
        "fa-light": "fasdl",
        "fa-thin": "fasdt"
      }
    },
    ga = {
      classic: {
        fab: "fa-brands",
        fad: "fa-duotone",
        fal: "fa-light",
        far: "fa-regular",
        fas: "fa-solid",
        fat: "fa-thin"
      },
      duotone: {
        fadr: "fa-regular",
        fadl: "fa-light",
        fadt: "fa-thin"
      },
      sharp: {
        fass: "fa-solid",
        fasr: "fa-regular",
        fasl: "fa-light",
        fast: "fa-thin"
      },
      "sharp-duotone": {
        fasds: "fa-solid",
        fasdr: "fa-regular",
        fasdl: "fa-light",
        fasdt: "fa-thin"
      }
    };

  const NAMESPACE_IDENTIFIER = '___FONT_AWESOME___';
  const PRODUCTION = (() => {
    try {
      return "production" === 'production';
    } catch (e$$1) {
      return false;
    }
  })();
  function familyProxy(obj) {
    // Defaults to the classic family if family is not available
    return new Proxy(obj, {
      get(target, prop) {
        return prop in target ? target[prop] : target[s];
      }
    });
  }
  const _PREFIX_TO_STYLE = _objectSpread2({}, S);

  // We changed FACSSClassesToStyleId in the icons repo to be canonical and as such, "classic" family does not have any
  // duotone styles.  But we do still need duotone in _PREFIX_TO_STYLE below, so we are manually adding
  // {'fa-duotone': 'duotone'}
  _PREFIX_TO_STYLE[s] = _objectSpread2(_objectSpread2(_objectSpread2(_objectSpread2({}, {
    'fa-duotone': 'duotone'
  }), S[s]), St['kit']), St['kit-duotone']);
  const PREFIX_TO_STYLE = familyProxy(_PREFIX_TO_STYLE);
  const _STYLE_TO_PREFIX = _objectSpread2({}, xt);

  // We changed FAStyleIdToShortPrefixId in the icons repo to be canonical and as such, "classic" family does not have any
  // duotone styles.  But we do still need duotone in _STYLE_TO_PREFIX below, so we are manually adding {duotone: 'fad'}
  _STYLE_TO_PREFIX[s] = _objectSpread2(_objectSpread2(_objectSpread2(_objectSpread2({}, {
    duotone: 'fad'
  }), _STYLE_TO_PREFIX[s]), Et['kit']), Et['kit-duotone']);
  const STYLE_TO_PREFIX = familyProxy(_STYLE_TO_PREFIX);
  const _PREFIX_TO_LONG_STYLE = _objectSpread2({}, ga);
  _PREFIX_TO_LONG_STYLE[s] = _objectSpread2(_objectSpread2({}, _PREFIX_TO_LONG_STYLE[s]), Wt['kit']);
  const PREFIX_TO_LONG_STYLE = familyProxy(_PREFIX_TO_LONG_STYLE);
  const _LONG_STYLE_TO_PREFIX = _objectSpread2({}, ua);
  _LONG_STYLE_TO_PREFIX[s] = _objectSpread2(_objectSpread2({}, _LONG_STYLE_TO_PREFIX[s]), Ct['kit']);
  const LONG_STYLE_TO_PREFIX = familyProxy(_LONG_STYLE_TO_PREFIX);
  const _FONT_WEIGHT_TO_PREFIX = _objectSpread2({}, G);
  const FONT_WEIGHT_TO_PREFIX = familyProxy(_FONT_WEIGHT_TO_PREFIX);

  function bunker(fn) {
    try {
      for (var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
        args[_key - 1] = arguments[_key];
      }
      fn(...args);
    } catch (e) {
      if (!PRODUCTION) {
        throw e;
      }
    }
  }

  const w = WINDOW || {};
  if (!w[NAMESPACE_IDENTIFIER]) w[NAMESPACE_IDENTIFIER] = {};
  if (!w[NAMESPACE_IDENTIFIER].styles) w[NAMESPACE_IDENTIFIER].styles = {};
  if (!w[NAMESPACE_IDENTIFIER].hooks) w[NAMESPACE_IDENTIFIER].hooks = {};
  if (!w[NAMESPACE_IDENTIFIER].shims) w[NAMESPACE_IDENTIFIER].shims = [];
  var namespace = w[NAMESPACE_IDENTIFIER];

  function normalizeIcons(icons) {
    return Object.keys(icons).reduce((acc, iconName) => {
      const icon = icons[iconName];
      const expanded = !!icon.icon;
      if (expanded) {
        acc[icon.iconName] = icon.icon;
      } else {
        acc[iconName] = icon;
      }
      return acc;
    }, {});
  }
  function defineIcons(prefix, icons) {
    let params = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    const {
      skipHooks = false
    } = params;
    const normalized = normalizeIcons(icons);
    if (typeof namespace.hooks.addPack === 'function' && !skipHooks) {
      namespace.hooks.addPack(prefix, normalizeIcons(icons));
    } else {
      namespace.styles[prefix] = _objectSpread2(_objectSpread2({}, namespace.styles[prefix] || {}), normalized);
    }

    /**
     * Font Awesome 4 used the prefix of `fa` for all icons. With the introduction
     * of new styles we needed to differentiate between them. Prefix `fa` is now an alias
     * for `fas` so we'll ease the upgrade process for our users by automatically defining
     * this as well.
     */
    if (prefix === 'fas') {
      defineIcons('fa', icons);
    }
  }

  var icons = {
    
    "buildings": [512,512,[],"e0cc",["M48 200l0 240c0 13.3 10.7 24 24 24l121.3 0c-.9-5.2-1.3-10.5-1.3-16l0-272L72 176c-13.3 0-24 10.7-24 24zm48 40c0-8.8 7.2-16 16-16l32 0c8.8 0 16 7.2 16 16l0 32c0 8.8-7.2 16-16 16l-32 0c-8.8 0-16-7.2-16-16l0-32zm0 96c0-8.8 7.2-16 16-16l32 0c8.8 0 16 7.2 16 16l0 32c0 8.8-7.2 16-16 16l-32 0c-8.8 0-16-7.2-16-16l0-32zM272 64l0 384c0 8.8 7.2 16 16 16l160 0c8.8 0 16-7.2 16-16l0-384c0-8.8-7.2-16-16-16L288 48c-8.8 0-16 7.2-16 16zm64 48c0-8.8 7.2-16 16-16l32 0c8.8 0 16 7.2 16 16l0 32c0 8.8-7.2 16-16 16l-32 0c-8.8 0-16-7.2-16-16l0-32zm0 96c0-8.8 7.2-16 16-16l32 0c8.8 0 16 7.2 16 16l0 32c0 8.8-7.2 16-16 16l-32 0c-8.8 0-16-7.2-16-16l0-32zm0 96c0-8.8 7.2-16 16-16l32 0c8.8 0 16 7.2 16 16l0 32c0 8.8-7.2 16-16 16l-32 0c-8.8 0-16-7.2-16-16l0-32z","M448 48c8.8 0 16 7.2 16 16l0 384c0 8.8-7.2 16-16 16l-160 0c-8.8 0-16-7.2-16-16l0-384c0-8.8 7.2-16 16-16l160 0zM288 0c-35.3 0-64 28.7-64 64l0 384c0 35.3 28.7 64 64 64l160 0c35.3 0 64-28.7 64-64l0-384c0-35.3-28.7-64-64-64L288 0zM192 128L72 128c-39.8 0-72 32.2-72 72L0 440c0 39.8 32.2 72 72 72l144.4 0c-11.8-13.2-20.1-29.7-23.1-48L72 464c-13.3 0-24-10.7-24-24l0-240c0-13.3 10.7-24 24-24l120 0 0-48zM112 320c-8.8 0-16 7.2-16 16l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0zm224 16c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0c-8.8 0-16 7.2-16 16l0 32zM112 224c-8.8 0-16 7.2-16 16l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0zM336 112l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0c-8.8 0-16 7.2-16 16zm16 144l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0c-8.8 0-16 7.2-16 16l0 32c0 8.8 7.2 16 16 16z"]],
    "folder": [512,512,["61716","128447","128193","folder-blank"],"f07b",["M48 96l0 320c0 8.8 7.2 16 16 16l384 0c8.8 0 16-7.2 16-16l0-256c0-8.8-7.2-16-16-16l-161.4 0c-10.6 0-20.8-4.2-28.3-11.7L213.1 87c-4.5-4.5-10.6-7-17-7L64 80c-8.8 0-16 7.2-16 16z","M0 96C0 60.7 28.7 32 64 32l132.1 0c19.1 0 37.4 7.6 50.9 21.1L289.9 96 448 96c35.3 0 64 28.7 64 64l0 256c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 96zM64 80c-8.8 0-16 7.2-16 16l0 320c0 8.8 7.2 16 16 16l384 0c8.8 0 16-7.2 16-16l0-256c0-8.8-7.2-16-16-16l-161.4 0c-10.6 0-20.8-4.2-28.3-11.7L213.1 87c-4.5-4.5-10.6-7-17-7L64 80z"]],
    "gamepad-modern": [640,512,["63676","127918","gamepad-alt"],"e5a2",["M48 369.4l0 2.8c0 33 26.8 59.8 59.8 59.8c27.4 0 51.4-18.7 58-45.3l3.6-14.3C174.8 351 194 336 216 336l208 0c22 0 41.2 15 46.6 36.4l3.6 14.3c6.7 26.6 30.6 45.3 58 45.3c33 0 59.8-26.8 59.8-59.8l0-2.8c0-3.5-.3-7.1-.9-10.6L558.4 168c-6.2-36-27.8-60.4-54.6-67.1C461.4 90.3 399.7 80 320 80s-141.5 10.3-183.7 20.9C109.4 107.6 87.8 132 81.6 168L48.9 358.8c-.6 3.5-.9 7-.9 10.6zM128 224c0-13.3 10.7-24 24-24l32 0 0-32c0-13.3 10.7-24 24-24s24 10.7 24 24l0 32 32 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-32 0 0 32c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-32-32 0c-13.3 0-24-10.7-24-24zm304 48a32 32 0 1 1 -64 0 32 32 0 1 1 64 0zm64-96a32 32 0 1 1 -64 0 32 32 0 1 1 64 0z","M216 336l208 0c22 0 41.2 15 46.6 36.4l3.6 14.3c6.7 26.6 30.6 45.3 58 45.3c33 0 59.8-26.8 59.8-59.8l0-2.8c0-3.5-.3-7.1-.9-10.6L558.4 168c-6.2-36-27.8-60.4-54.6-67.1C461.4 90.3 399.7 80 320 80s-141.5 10.3-183.7 20.9C109.4 107.6 87.8 132 81.6 168L48.9 358.8c-.6 3.5-.9 7-.9 10.6l0 2.8c0 33 26.8 59.8 59.8 59.8c27.4 0 51.4-18.7 58-45.3l3.6-14.3C174.8 351 194 336 216 336zm211.6 62.3L424 384l-208 0-3.6 14.3c-12 48-55.1 81.7-104.6 81.7C48.3 480 0 431.7 0 372.2l0-2.8c0-6.3 .5-12.5 1.6-18.7L34.3 159.8c8.6-50.2 40.9-93.2 90.3-105.5C170.5 42.9 236.2 32 320 32s149.5 10.9 195.3 22.3c49.4 12.3 81.7 55.3 90.3 105.5l32.7 190.9c1.1 6.2 1.6 12.4 1.6 18.7l0 2.8C640 431.7 591.7 480 532.2 480c-49.5 0-92.6-33.7-104.6-81.7zM232 168l0 32 32 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-32 0 0 32c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-32-32 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l32 0 0-32c0-13.3 10.7-24 24-24s24 10.7 24 24zm168 72a32 32 0 1 1 0 64 32 32 0 1 1 0-64zm32-64a32 32 0 1 1 64 0 32 32 0 1 1 -64 0z"]],
    "location-dot": [384,512,["map-marker-alt"],"f3c5",["M48 192c0 12.4 4.5 31.6 15.3 57.2c10.5 24.8 25.4 52.2 42.5 79.9c28.5 46.2 61.5 90.8 86.2 122.6c24.8-31.8 57.8-76.4 86.2-122.6c17.1-27.7 32-55.1 42.5-79.9C331.5 223.6 336 204.4 336 192c0-79.5-64.5-144-144-144S48 112.5 48 192zm224 0a80 80 0 1 1 -160 0 80 80 0 1 1 160 0z","M336 192c0-79.5-64.5-144-144-144S48 112.5 48 192c0 12.4 4.5 31.6 15.3 57.2c10.5 24.8 25.4 52.2 42.5 79.9c28.5 46.2 61.5 90.8 86.2 122.6c24.8-31.8 57.8-76.4 86.2-122.6c17.1-27.7 32-55.1 42.5-79.9C331.5 223.6 336 204.4 336 192zm48 0c0 87.4-117 243-168.3 307.2c-12.3 15.3-35.1 15.3-47.4 0C117 435 0 279.4 0 192C0 86 86 0 192 0S384 86 384 192zm-160 0a32 32 0 1 0 -64 0 32 32 0 1 0 64 0zm-112 0a80 80 0 1 1 160 0 80 80 0 1 1 -160 0z"]],
    "puzzle-piece": [512,512,["129513"],"f12e",["M48 152l0 52.5c7.4-2.9 15.5-4.5 24-4.5c43.1 0 72 39.4 72 80s-28.9 80-72 80c-8.5 0-16.6-1.6-24-4.5L48 456c0 4.4 3.6 8 8 8l100.5 0c-2.9-7.4-4.5-15.5-4.5-24c0-43.1 39.4-72 80-72s80 28.9 80 72c0 8.5-1.6 16.6-4.5 24l52.5 0c4.4 0 8-3.6 8-8l0-129.3c0-17 13.8-30.7 30.7-30.7c11.1 0 20.3 5.8 25.6 13.6c5.5 8 11.4 10.4 15.6 10.4c4 0 9.5-2.1 14.7-9.1s9.3-17.9 9.3-30.9s-4-23.8-9.3-30.9s-10.7-9.1-14.7-9.1c-4.2 0-10.1 2.4-15.6 10.4c-5.3 7.8-14.6 13.6-25.6 13.6c-17 0-30.7-13.8-30.7-30.7l0-81.3c0-4.4-3.6-8-8-8l-81.3 0c-17 0-30.7-13.8-30.7-30.7c0-11.1 5.8-20.3 13.6-25.6c8-5.5 10.4-11.4 10.4-15.6c0-4-2.1-9.5-9.1-14.7S245 48 232 48s-23.8 4-30.9 9.3S192 68 192 72c0 4.2 2.4 10.1 10.4 15.6c7.8 5.3 13.6 14.6 13.6 25.6c0 17-13.8 30.7-30.7 30.7L56 144c-4.4 0-8 3.6-8 8z","M201.1 57.3C194.1 62.5 192 68 192 72c0 4.2 2.4 10.1 10.4 15.6c7.8 5.3 13.6 14.6 13.6 25.6c0 17-13.8 30.7-30.7 30.7L56 144c-4.4 0-8 3.6-8 8l0 52.5c7.4-2.9 15.5-4.5 24-4.5c43.1 0 72 39.4 72 80s-28.9 80-72 80c-8.5 0-16.6-1.6-24-4.5L48 456c0 4.4 3.6 8 8 8l100.5 0c-2.9-7.4-4.5-15.5-4.5-24c0-43.1 39.4-72 80-72s80 28.9 80 72c0 8.5-1.6 16.6-4.5 24l52.5 0c4.4 0 8-3.6 8-8l0-129.3c0-17 13.8-30.7 30.7-30.7c11.1 0 20.3 5.8 25.6 13.6c5.5 8 11.4 10.4 15.6 10.4c4 0 9.5-2.1 14.7-9.1s9.3-17.9 9.3-30.9s-4-23.8-9.3-30.9s-10.7-9.1-14.7-9.1c-4.2 0-10.1 2.4-15.6 10.4c-5.3 7.8-14.6 13.6-25.6 13.6c-17 0-30.7-13.8-30.7-30.7l0-81.3c0-4.4-3.6-8-8-8l-81.3 0c-17 0-30.7-13.8-30.7-30.7c0-11.1 5.8-20.3 13.6-25.6c8-5.5 10.4-11.4 10.4-15.6c0-4-2.1-9.5-9.1-14.7S245 48 232 48s-23.8 4-30.9 9.3zM172.3 18.9C188.5 6.8 209.6 0 232 0s43.5 6.8 59.7 18.9S320 49.5 320 72c0 8.6-1.8 16.7-4.9 24L360 96c30.9 0 56 25.1 56 56l0 44.9c7.3-3.1 15.4-4.9 24-4.9c22.5 0 41 12.2 53.1 28.3S512 257.6 512 280s-6.8 43.5-18.9 59.7S462.5 368 440 368c-8.6 0-16.7-1.8-24-4.9l0 92.9c0 30.9-25.1 56-56 56l-78.1 0c-18.7 0-33.9-15.2-33.9-33.9c0-10.1 4.5-18.5 9.9-24.2c4.2-4.3 6.1-9.2 6.1-13.9c0-9.9-10.7-24-32-24s-32 14.1-32 24c0 4.7 1.9 9.5 6.1 13.9c5.5 5.7 9.9 14.1 9.9 24.2c0 18.7-15.2 33.9-33.9 33.9L56 512c-30.9 0-56-25.1-56-56L0 329.9C0 311.2 15.2 296 33.9 296c10.1 0 18.5 4.5 24.2 9.9c4.3 4.2 9.2 6.1 13.9 6.1c9.9 0 24-10.7 24-32s-14.1-32-24-32c-4.7 0-9.5 1.9-13.9 6.1C52.4 259.5 44 264 33.9 264C15.2 264 0 248.8 0 230.1L0 152c0-30.9 25.1-56 56-56l92.9 0c-3.1-7.3-4.9-15.4-4.9-24c0-22.5 12.2-41 28.3-53.1z"]],
    "square-poll-vertical": [448,512,["poll"],"f681",["M48 96l0 320c0 8.8 7.2 16 16 16l320 0c8.8 0 16-7.2 16-16l0-320c0-8.8-7.2-16-16-16L64 80c-8.8 0-16 7.2-16 16zm56 152c0-13.3 10.7-24 24-24s24 10.7 24 24l0 112c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-112zm96-96c0-13.3 10.7-24 24-24s24 10.7 24 24l0 208c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-208zm96 160c0-13.3 10.7-24 24-24s24 10.7 24 24l0 48c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-48z","M64 80c-8.8 0-16 7.2-16 16l0 320c0 8.8 7.2 16 16 16l320 0c8.8 0 16-7.2 16-16l0-320c0-8.8-7.2-16-16-16L64 80zM0 96C0 60.7 28.7 32 64 32l320 0c35.3 0 64 28.7 64 64l0 320c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 96zM128 224c13.3 0 24 10.7 24 24l0 112c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-112c0-13.3 10.7-24 24-24zm72-72c0-13.3 10.7-24 24-24s24 10.7 24 24l0 208c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-208zM320 288c13.3 0 24 10.7 24 24l0 48c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-48c0-13.3 10.7-24 24-24z"]],
    "tarp": [576,512,[],"e57b",["M48 128c0-8.8 7.2-16 16-16l448 0c8.8 0 16 7.2 16 16l0 160-80 0c-17.7 0-32 14.3-32 32l0 80L64 400c-8.8 0-16-7.2-16-16l0-256zm32 48a32 32 0 1 0 64 0 32 32 0 1 0 -64 0z","M48 128c0-8.8 7.2-16 16-16l448 0c8.8 0 16 7.2 16 16l0 160-80 0c-17.7 0-32 14.3-32 32l0 80L64 400c-8.8 0-16-7.2-16-16l0-256zm528 0c0-35.3-28.7-64-64-64L64 64C28.7 64 0 92.7 0 128L0 384c0 35.3 28.7 64 64 64l364.1 0c12.7 0 24.9-5.1 33.9-14.1l99.9-99.9c9-9 14.1-21.2 14.1-33.9L576 128zM112 208a32 32 0 1 0 0-64 32 32 0 1 0 0 64z"]],
    "thumbtack": [384,512,["128392","128204","thumb-tack"],"f08d",["M52.5 304L168 304l0-88c0-13.3 10.7-24 24-24s24 10.7 24 24l0 88 115.5 0-1.3-5.1c-7.4-29.5-25.2-54.1-49.1-70.2c-12.1-8.2-19.8-21.5-20.9-36L249.4 51.7c-.1-1.2-.1-2.5-.1-3.7L134.8 48c0 1.2 0 2.5-.1 3.7L123.8 192.6c-1.1 14.6-8.8 27.8-20.9 36C79 244.8 61.1 269.4 53.8 298.9L52.5 304z","M134.6 51.7L123.8 192.6c-1.1 14.6-8.8 27.8-20.9 36C79 244.8 61.1 269.4 53.8 298.9L52.5 304 168 304l0-88c0-13.3 10.7-24 24-24s24 10.7 24 24l0 88 115.5 0-1.3-5.1c-7.4-29.5-25.2-54.1-49.1-70.2c-12.1-8.2-19.8-21.5-20.9-36L249.4 51.7c-.1-1.2-.1-2.5-.1-3.7L134.8 48c0 1.2 0 2.5-.1 3.7zM168 352L32 352c-9.9 0-19.2-4.5-25.2-12.3S-1.4 321.8 1 312.2l6.2-25c10.3-41.3 35.4-75.7 68.7-98.3L83.1 96l3.7-48L56 48c-4.4 0-8.6-1.2-12.2-3.3C36.8 40.5 32 32.8 32 24C32 10.7 42.7 0 56 0L86.8 0 297.2 0 328 0c13.3 0 24 10.7 24 24c0 8.8-4.8 16.5-11.8 20.7c-3.6 2.1-7.7 3.3-12.2 3.3l-30.8 0 3.7 48 7.1 92.9c33.3 22.6 58.4 57.1 68.7 98.3l6.2 25c2.4 9.6 .2 19.7-5.8 27.5s-15.4 12.3-25.2 12.3l-136 0 0 136c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-136z"]],
    "user": [448,512,["62144","128100"],"f007",["M49.3 464c8.9-63.3 63.3-112 129-112l91.4 0c65.7 0 120.1 48.7 129 112L49.3 464zM304 128a80 80 0 1 1 -160 0 80 80 0 1 1 160 0z","M304 128a80 80 0 1 0 -160 0 80 80 0 1 0 160 0zM96 128a128 128 0 1 1 256 0A128 128 0 1 1 96 128zM49.3 464l349.5 0c-8.9-63.3-63.3-112-129-112l-91.4 0c-65.7 0-120.1 48.7-129 112zM0 482.3C0 383.8 79.8 304 178.3 304l91.4 0C368.2 304 448 383.8 448 482.3c0 16.4-13.3 29.7-29.7 29.7L29.7 512C13.3 512 0 498.7 0 482.3z"]],
    "user-graduate": [448,512,[],"f501",["M49.3 464l143.8 0c-6.2-3.4-11.9-7.9-16.9-13.6l-63.6-71.5C79.3 394.8 55.1 426.4 49.3 464zM144 145.1l0 14.9c0 44.2 35.8 80 80 80s80-35.8 80-80l0-14.9c-23 4.6-46 9.2-69 13.8c-7.2 1.5-14.7 1.5-22 0c-23-4.6-46-9.2-69-13.8zM254.9 464l143.8 0c-5.8-37.6-30-69.2-63.3-85.1l-63.6 71.5c-5 5.6-10.7 10.1-16.9 13.6z","M228.7 .5c-3.1-.6-6.3-.6-9.4 0l-200 40C8.1 42.7 0 52.6 0 64C0 74.3 6.5 83.3 16 86.6l0 71.8L.3 236.9c-.9 4.7 .3 9.6 3.3 13.3s7.6 5.9 12.4 5.9l32 0c4.8 0 9.3-2.1 12.4-5.9s4.3-8.6 3.3-13.3L48 158.4l0-65.1 171.3 34.3c3.1 .6 6.3 .6 9.4 0l200-40C439.9 85.3 448 75.4 448 64s-8.1-21.3-19.3-23.5l-200-40zM49.3 464c5.8-37.6 30-69.2 63.3-85.1l63.6 71.5c5 5.6 10.7 10.1 16.9 13.6L49.3 464zm349.4 0l-143.8 0c6.2-3.4 11.9-7.9 16.9-13.6l63.6-71.5c33.3 15.8 57.5 47.4 63.3 85.1zM109.6 328.4C45.9 350 0 410.3 0 481.3c0 17 13.8 30.7 30.7 30.7l386.6 0c17 0 30.7-13.8 30.7-30.7c0-71-45.9-131.3-109.6-152.8c-10.9-3.7-22.7 .4-30.3 9L236 418.5c-6.4 7.2-17.6 7.2-23.9 0l-72.1-81.1c-7.6-8.6-19.4-12.7-30.3-9zM96 160c0 70.7 57.3 128 128 128s128-57.3 128-128l0-24.5-48 9.6 0 14.9c0 44.2-35.8 80-80 80s-80-35.8-80-80l0-14.9-48-9.6L96 160z"]],
    "user-group": [640,512,["128101","user-friends"],"f500",["M49.3 464l349.5 0c-8.9-63.3-63.3-112-129-112l-91.4 0c-65.7 0-120.1 48.7-129 112zM144 128a80 80 0 1 0 160 0 80 80 0 1 0 -160 0z","M224 48a80 80 0 1 1 0 160 80 80 0 1 1 0-160zm0 208A128 128 0 1 0 224 0a128 128 0 1 0 0 256zm-45.7 96l91.4 0c65.7 0 120.1 48.7 129 112L49.3 464c8.9-63.3 63.3-112 129-112zm0-48C79.8 304 0 383.8 0 482.3C0 498.7 13.3 512 29.7 512l388.6 0c16.4 0 29.7-13.3 29.7-29.7C448 383.8 368.2 304 269.7 304l-91.4 0zm431 208c17 0 30.7-13.8 30.7-30.7C640 392.2 567.8 320 478.7 320l-61.4 0c-4.4 0-8.8 .2-13.2 .5c46.4 38.6 75.9 96.7 75.9 161.8c0 10.8-2.8 20.9-7.6 29.7l136.9 0zM432 256c61.9 0 112-50.1 112-112s-50.1-112-112-112c-24.8 0-47.7 8.1-66.3 21.7C377.4 75.9 384 101.2 384 128c0 35.6-11.6 68.5-31.3 95.1C373 243.4 401 256 432 256z"]],
    "user-group-simple": [640,512,[],"e603",["M48 416l0 16 224 0 0-16c0-44.2-35.8-80-80-80l-64 0c-44.2 0-80 35.8-80 80zm56-280a56 56 0 1 0 112 0 56 56 0 1 0 -112 0z","M104 136a56 56 0 1 1 112 0 56 56 0 1 1 -112 0zm160 0A104 104 0 1 0 56 136a104 104 0 1 0 208 0zm216 88a96 96 0 1 0 0-192 96 96 0 1 0 0 192zM128 336l64 0c44.2 0 80 35.8 80 80l0 16L48 432l0-16c0-44.2 35.8-80 80-80zm0-48C57.3 288 0 345.3 0 416l0 16c0 26.5 21.5 48 48 48l224 0c26.5 0 48-21.5 48-48l0-16c0-70.7-57.3-128-128-128l-64 0zM448 480l64 0c70.7 0 128-57.3 128-128l0-16c0-26.5-21.5-48-48-48l-224 0c-21.8 0-40.3 14.6-46.1 34.6C340.8 348.9 352 381.1 352 416l0 16c0 1.5 0 3-.1 4.5C375.3 463.2 409.7 480 448 480z"]],
    "user-tie": [448,512,[],"f508",["M49.3 464l113 0-43.8-87.7C82.3 391.1 55.4 424.2 49.3 464zM144 128a80 80 0 1 0 160 0 80 80 0 1 0 -160 0zM285.7 464l113 0c-6.1-39.8-33-72.9-69.2-87.7L285.7 464z","M224 208a80 80 0 1 0 0-160 80 80 0 1 0 0 160zm128-80A128 128 0 1 1 96 128a128 128 0 1 1 256 0zM209.1 359.2l-18.6-31c-6.4-10.7 1.3-24.2 13.7-24.2l19.7 0 19.7 0c12.4 0 20.1 13.6 13.7 24.2l-18.6 31 15.9 59.2 43.8-87.6c3-6 9.4-9.5 15.9-8.4C390.4 335.6 448 401.7 448 481.3c0 17-13.8 30.7-30.7 30.7L30.7 512C13.8 512 0 498.2 0 481.3c0-79.6 57.6-145.7 133.5-158.9c6.6-1.1 12.9 2.4 15.9 8.4l43.8 87.6 15.9-59.2zm-90.6 17.1C82.3 391.1 55.4 424.2 49.3 464l113 0-43.8-87.7zM285.7 464l113 0c-6.1-39.8-33-72.9-69.2-87.7L285.7 464z"]]

  };
  var prefixes = [null    ,'fadr',
    ,'fa-regular'
];
  bunker(() => {
    for (const prefix of prefixes) {
      if (!prefix) continue;
      defineIcons(prefix, icons);
    }
  });

}());
