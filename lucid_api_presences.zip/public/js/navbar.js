// $(document).ready(function () {
//   const url = $(location).attr('href');
//   const endpoint = url.split('/');
//   const id = $('.link').attr('id');
//   // console.log(id + '=' + endpoint[3]);

//   if ($('#' + endpoint[3]).hasClass('link')) {
//     $('#' + endpoint[3]).addClass('bg-[#81338a]/60');
//   } else {
//     if (endpoint[3] == 'formations' || endpoint[3] == 'modules') {
//       // console.log('mety');
//       $('#catalogue').addClass(`text-purple-500 bg-gray-200`);
//     }
//     $('#' + endpoint[3]).addClass(`text-purple-500 bg-gray-200`);
//   }
// });