<?php
return [
  'phraseDeconnexion' => 'Do you really want to disconnect?',
  'nonAnnuler' => 'No, cancel',
  'ouiConfirmer' => 'Yes, I agree',
];