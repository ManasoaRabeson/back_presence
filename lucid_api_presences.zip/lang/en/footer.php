<?php
return [
  'aide' => 'Help',
  'contact' => 'Contact',
  'securite' => 'Security',
  'viePrive' => 'Privacy policy',
  'contrat' => "Usage contract",
  'mentions' => 'Terms and Conditions',
  'droitResesve' => 'All rights reserved',
];