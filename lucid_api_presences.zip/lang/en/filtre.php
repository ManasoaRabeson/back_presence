<?php
return [
  'search' => 'Student search',
  'periodeFormation' => 'Training period',
  'cours' => 'Courses',
  'modaliteFormation' => 'Training method',
  'statutFormation' => 'Training status',
  'resetFiltre' => 'Reset filter',
];