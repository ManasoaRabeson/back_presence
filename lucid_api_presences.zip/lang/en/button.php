<?php
return [
  'motDePasse' => "Password and Security",
  'editProfilEtp' => "Edit company profile",
  'editProfilRef' => "Edit my profile",
  'ajoutRef' => "New referent",
  'ajoutCompteBanque' => "New bank accounts",
  'ajoutCompteMobileMoney' => "New mobile money accounts",
  'modifier' => "Edit",
  'supprimer' => "Delete",
  'editerCompteBank' => "Edit my bank account",
  'editerCompteMobileMoney' => "Edit my mobile money account",
  'nouveauRef' => "New referent",
  'sauvegarder' => "Save",
  'nouveau' => 'New',
  'ajouter' => 'Add',

  'dupliquer' => 'Duplicate',
  'reporter' => 'Report',
  'cloturer' => 'Close',
  'valider' => 'Validate project',
  'statut' => 'Status',

  'editer' => 'Edit',
  'allerDossier' => 'Go to the folder',
];