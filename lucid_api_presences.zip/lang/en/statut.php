<?php
return [
  'enCours' => 'In progress',
  'enPreparation' => 'In preparation',
  'planifie' => 'Planned',
  'termine' => 'Completed',
  'cloture' => 'Closed',

  'presentielle' => 'Presential',
  'enligne' => 'Online',
  'blended' => 'Blended',
  'nonRenseigne' => 'Unknown',

  'placeReserve' => 'Reserved places',
  'nonClasse' => 'Unclassified',
  'avis' => 'advices',
];