<?php
return [
  'search' => 'Rechercher un apprenant',
  'periodeFormation' => 'Période de formation',
  'cours' => 'Cours',
  'modaliteFormation' => 'Modalité de formation',
  'statutFormation' => 'Statut de formation',
  'resetFiltre' => 'Réinitialiser le filtre',
];