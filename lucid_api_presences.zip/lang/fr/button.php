<?php
return [
  'motDePasse' => "Mot de passe et sécurité",
  'editProfilEtp' => "Editer le profil de l'entreprise",
  'editProfilRef' => "Editer mon profil",
  'ajoutRef' => "Nouveau référent",
  'ajoutCompteBanque' => "Nouveau compte bancaire",
  'ajoutCompteMobileMoney' => "Nouveau compte mobile money",
  'modifier' => "Modifier",
  'supprimer' => "Supprimer",
  'editerCompteBank' => "Editer mon compte bancaire",
  'editerCompteMobileMoney' => "Editer mon compte mobile money",
  'nouveauRef' => "Nouveau",
  'sauvegarder' => "Sauvegarder",
  'nouveau' => 'Nouveau',
  'ajouter' => 'Ajouter',

  'dupliquer' => 'Dupliquer',
  'reporter' => 'Reporter',
  'cloturer' => 'Clôturer',
  'valider' => 'Valider le projet',
  'statut' => 'Statut',

  'editer' => 'Editer',
  'allerDossier' => 'Aller dans le dossier',
];