<?php
return [
  'aide' => 'Aide',
  'contact' => 'Contact',
  'securite' => 'Sécurité',
  'viePrive' => 'Respect de la vie privée',
  'contrat' => "Contract d'utilisation",
  'mentions' => 'Mentions Légales',
  'droitResesve' => 'Tous droits réservés',
];