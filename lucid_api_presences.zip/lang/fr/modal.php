<?php
return [
  'phraseDeconnexion' => 'Voulez-vous vraiment vous deconnectez ?',
  'nonAnnuler' => 'Non, annuler',
  'ouiConfirmer' => 'Oui, confirmer',
];