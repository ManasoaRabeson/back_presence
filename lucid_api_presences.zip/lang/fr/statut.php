<?php
return [
  'enCours' => 'En cours',
  'enPreparation' => 'En préparation',
  'planifie' => 'Planifié',
  'termine' => 'Terminé',
  'cloture' => 'Clôturé',

  'presentielle' => 'Présentielle',
  'enligne' => 'En ligne',
  'blended' => 'Blended',
  'nonRenseigne' => 'Non renseigné',

  'placeReserve' => 'Places réservées',
  'nonClasse' => 'Non classé',
  'avis' => 'avis',
];