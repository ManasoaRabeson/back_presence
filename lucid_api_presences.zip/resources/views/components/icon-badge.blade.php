<span class="absolute -top-2 -right-2 cursor-pointer" title="Entreprise non membre de Forma-Fusion">
  <i class="fa-solid fa-triangle-exclamation text-lg text-amber-500 relative"></i>
  {{-- <i class="fa-solid fa-xmark text-white text-lg absolute top-[4px] right-[6px]"></i> --}}
</span>
