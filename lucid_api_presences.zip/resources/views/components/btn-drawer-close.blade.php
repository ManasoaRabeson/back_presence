@php
    $id ??= '';
@endphp
<div data-bs-toggle="offcanvas" href="{{ $id }}" class="mr-3 btn">Annuler</div>
